﻿using ITBloggerMoses.Models;
using System.Linq;
using System.Web.Mvc;

namespace ITBloggerMoses.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _db = new ApplicationDbContext(); 

        public ActionResult Index()
        {
            var blogPosts = _db.BlogPosts.ToList();
            return View(blogPosts);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult SamplePost()
        {
            ViewBag.Message = "Your sample post.";

            return View();    

        }
    }
}